let accordeons = document.querySelectorAll(".accordeon")
for (let i = 0; i <accordeons.length; i++){
    accordeons[i].addEventListener("click",function (){
        console.log("Accordeon" + i);
        this.classList.toggle("open")
    })
}
let darkButton = document.querySelector(".darkmode")

darkButton.addEventListener("click", ()=>{
    let body = document.querySelector("body")
    if(body.classList.contains("dark")){
        body.classList.remove("dark")
        console.log("active")
    }else{
        body.classList.add("dark")
        console.log("desactive")

    }        
})
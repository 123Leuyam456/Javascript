document.addEventListener('DOMContentLoaded',function(){

    const swiper = new Swiper(".planet",{
        navigation: {
            nextEL: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
            pagination: {
            el: ".swiper-pagination",
        },
            autoplay: {
                delay: 2000
        }
    })
})

const lightbox = new SimpleLightbox(".card a")

const options = {
    gutterPixels: 50,
}

const filterizr = new Filterizr(".portfolio-elements", options);

let filtersList = document.querySelectorAll(".filters li")
filtersList.forEach(function(filterItem){
    filterItem.addEventListener("click", function(){
        document.querySelector(".filters .active").classList.remove("active")
        this.classList.add("active")
    })
})

let form = document.querySelector("form")


form.addEventListener("submit", function(event){
    event.preventDefault();

    let errorContainer = document.querySelector('.message-error')
    let errorList= document.querySelector('.message-error ul')
    errorList.innerHTML=""
    errorContainer.classList.remove('visible')

    let email = document.querySelector('#email')
    let successContainer = document.querySelector('.message-success')
    successContainer.classList.remove('visible')    

    if (email.value == '') {
        errorContainer.classList.add('visible')
        email.classList.add('defeat')
        email.classList.remove("success")

        let err = document.createElement("li")
        err.innerText = "Le champ email ne peut pas etre vide"
        errorList.appendChild(err)
    }else{
        email.classList.remove('defeat')
        email.classList.add('success')
    }

    if(
        email.classList.contains("success")
    ){
        successContainer.classList.add('visible')
    }
})

let darkButton = document.querySelector(".darkmode")

darkButton.addEventListener("click", ()=>{
    let body = document.querySelector("body")
    if(body.classList.contains("dark")){
        body.classList.remove("dark")
        console.log("active")
    }else{
        body.classList.add("dark")
        console.log("desactive")

    }        
})